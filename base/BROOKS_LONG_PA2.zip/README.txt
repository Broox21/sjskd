For this program a user should run it, enter how large of an array they would like to fill with numbers, then enter numbers until you have reached the array size

The program will not allow garbage to be inputted, such as letters


